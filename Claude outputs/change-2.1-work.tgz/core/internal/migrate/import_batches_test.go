package migrate

import (
	"database/sql"
	"errors"
	"testing"

	"github.com/jackc/pgx/v5/pgconn"
)

// The proof that migration 00008 does what change 2.1's design claims, rather
// than merely applying.
//
// Everything here runs as vekst_app against a database migrated by a
// non-superuser vekst_migrator, for the reason tenancy_test.go states: a
// superuser owner bypasses row-level security unconditionally, so the same
// assertions against a superuser-owned schema would pass while proving nothing.
//
// The constraint in §"measured past upload" is the one worth reading. An
// earlier draft of 00008 omitted 'failed' from its exempt statuses, which made
// the single failure the design names -- an object missing from the store,
// before anything could measure it -- impossible to record. That was found by
// running this kind of test, not by reading the migration.

// newBatch inserts one batch for org and returns its id. Every column 00008
// adds NOT NULL has to be supplied, which is itself the point: a batch cannot
// exist without an uploader, a name, a declared size and an expiry.
func newBatch(t *testing.T, tx *sql.Tx, org, entity, user, key, status string) string {
	t.Helper()
	var id string
	err := tx.QueryRow(
		`INSERT INTO import_batches (
		     org_id, entity_id, uploaded_by, source_kind, status,
		     file_name, declared_bytes, declared_type, file_key,
		     file_sha256, byte_length, content_type, upload_expires_at)
		 VALUES ($1,$2,$3,'bank',$4,'stmt.csv',1024,'text/csv',$5,
		         decode(repeat('00',32),'hex'),1024,'text/csv', now() + interval '15 min')
		 RETURNING id`,
		org, entity, user, status, key).Scan(&id)
	if err != nil {
		t.Fatalf("inserting batch: %v", err)
	}
	return id
}

// tenantTx opens a transaction on the app connection with the tenant context
// set the way db.InTx sets it: transaction-locally, never as a session
// variable, so it cannot outlive the transaction on a pooled connection.
func tenantTx(t *testing.T, db *sql.DB, org string) *sql.Tx {
	t.Helper()
	tx, err := db.Begin()
	if err != nil {
		t.Fatalf("begin: %v", err)
	}
	if _, err := tx.Exec(`SELECT set_config('app.org_id', $1, true)`, org); err != nil {
		tx.Rollback() //nolint:errcheck // already failing
		t.Fatalf("setting tenant context: %v", err)
	}
	return tx
}

func pgErr(t *testing.T, err error) *pgconn.PgError {
	t.Helper()
	var pg *pgconn.PgError
	if !errors.As(err, &pg) {
		t.Fatalf("expected a Postgres error, got %v", err)
	}
	return pg
}

// A batch that failed BEFORE it could be measured must be recordable. This is
// the upload_missing case: core never sees the bytes, so when the object is not
// in the store there is nothing to hash, and a constraint that demanded a hash
// would make the failure unstorable.
func TestAFailureBeforeMeasurementIsRecordable(t *testing.T) {
	f := newTenantFixture(t, "vekst_import_batches_test")

	tx := tenantTx(t, f.app, orgA)
	defer tx.Rollback() //nolint:errcheck

	if _, err := tx.Exec(
		`INSERT INTO import_batches (
		     org_id, entity_id, uploaded_by, source_kind, status,
		     file_name, declared_bytes, declared_type, file_key,
		     failure_code, upload_expires_at)
		 VALUES ($1,$2,$3,'bank','failed','stmt.csv',1024,'text/csv','org/a/1',
		         'upload_missing', now())`,
		orgA, f.entityA, f.userA); err != nil {
		t.Fatalf("a batch that failed before measurement must be storable: %v", err)
	}
}

// ...and the guarantee the exemption must not cost: a batch cannot claim to
// have been uploaded without the three measurements, because every later stage
// reads them as facts about the file.
func TestAnUnmeasuredBatchCannotClaimToBeUploaded(t *testing.T) {
	f := newTenantFixture(t, "vekst_import_batches_test")

	tx := tenantTx(t, f.app, orgA)
	defer tx.Rollback() //nolint:errcheck

	_, err := tx.Exec(
		`INSERT INTO import_batches (
		     org_id, entity_id, uploaded_by, source_kind, status,
		     file_name, declared_bytes, declared_type, file_key, upload_expires_at)
		 VALUES ($1,$2,$3,'bank','uploaded','stmt.csv',1024,'text/csv','org/a/2', now())`,
		orgA, f.entityA, f.userA)
	if err == nil {
		t.Fatal("an unmeasured batch was accepted as uploaded")
	}
	if got := pgErr(t, err).ConstraintName; got != "import_batches_measured_past_upload" {
		t.Errorf("refused by %q, want import_batches_measured_past_upload", got)
	}
}

// 00007's placeholder state must not survive 00008. It names the same thing as
// 'imported', and two names for one state is the drift 00007's deliberately
// narrow CHECK existed to make visible.
func TestThePlaceholderStateIsGone(t *testing.T) {
	f := newTenantFixture(t, "vekst_import_batches_test")

	tx := tenantTx(t, f.app, orgA)
	defer tx.Rollback() //nolint:errcheck

	_, err := tx.Exec(
		`INSERT INTO import_batches (
		     org_id, entity_id, uploaded_by, source_kind, status,
		     file_name, declared_bytes, declared_type, file_key,
		     file_sha256, byte_length, content_type, upload_expires_at)
		 VALUES ($1,$2,$3,'bank','persisted','s.csv',1,'text/csv','org/a/3',
		         decode(repeat('00',32),'hex'),1,'text/csv', now())`,
		orgA, f.entityA, f.userA)
	if err == nil {
		t.Fatal("'persisted' is still an accepted status")
	}
	if got := pgErr(t, err).ConstraintName; got != "import_batches_status_check" {
		t.Errorf("refused by %q, want import_batches_status_check", got)
	}
}

// A batch belongs to one organisation and is invisible to every other, whatever
// its status.
func TestBatchesAreIsolatedBetweenOrganisations(t *testing.T) {
	f := newTenantFixture(t, "vekst_import_batches_test")

	txA := tenantTx(t, f.app, orgA)
	id := newBatch(t, txA, orgA, f.entityA, f.userA, "org/a/iso", "uploaded")
	if err := txA.Commit(); err != nil {
		t.Fatalf("commit: %v", err)
	}

	txB := tenantTx(t, f.app, orgB)
	defer txB.Rollback() //nolint:errcheck

	var n int
	if err := txB.QueryRow(`SELECT count(*) FROM import_batches`).Scan(&n); err != nil {
		t.Fatalf("counting as B: %v", err)
	}
	if n != 0 {
		t.Errorf("organisation B sees %d of A's batches, want 0", n)
	}

	// A write B is not entitled to make must affect no row rather than raise:
	// row-level security filters UPDATE silently, which is exactly why every
	// single-row write in this schema goes through db.ExactlyOneRow.
	res, err := txB.Exec(`UPDATE import_batches SET status = 'abandoned' WHERE id = $1`, id)
	if err != nil {
		t.Fatalf("update as B: %v", err)
	}
	if rows, _ := res.RowsAffected(); rows != 0 {
		t.Errorf("organisation B updated %d of A's rows, want 0", rows)
	}
}

// The object key is unique within an organisation and says nothing across them.
// Scoping it is about the cross-tenant oracle, not about bucket collisions --
// the key embeds a random uuid, so two organisations cannot collide regardless.
func TestFileKeyUniquenessIsScopedByOrganisation(t *testing.T) {
	f := newTenantFixture(t, "vekst_import_batches_test")

	txA := tenantTx(t, f.app, orgA)
	newBatch(t, txA, orgA, f.entityA, f.userA, "shared/key", "uploaded")
	if err := txA.Commit(); err != nil {
		t.Fatalf("commit A: %v", err)
	}

	// B may reuse the same key: it is a different file in a different tenant.
	txB := tenantTx(t, f.app, orgB)
	newBatch(t, txB, orgB, f.entityB, f.userA, "shared/key", "uploaded")
	if err := txB.Commit(); err != nil {
		t.Fatalf("organisation B could not reuse A's key: %v", err)
	}

	// A may not reuse its own.
	txA2 := tenantTx(t, f.app, orgA)
	defer txA2.Rollback() //nolint:errcheck
	_, err := txA2.Exec(
		`INSERT INTO import_batches (
		     org_id, entity_id, uploaded_by, source_kind, status,
		     file_name, declared_bytes, declared_type, file_key,
		     file_sha256, byte_length, content_type, upload_expires_at)
		 VALUES ($1,$2,$3,'bank','uploaded','dup.csv',1,'text/csv','shared/key',
		         decode(repeat('00',32),'hex'),1,'text/csv', now())`,
		orgA, f.entityA, f.userA)
	if err == nil {
		t.Fatal("an organisation reused its own file key")
	}
	if got := pgErr(t, err).ConstraintName; got != "import_batches_file_key_unique" {
		t.Errorf("refused by %q, want import_batches_file_key_unique", got)
	}
}

// source_kind decides which rows a report line may be computed from, and the
// basis label -- cash or accrual -- is derived from it rather than chosen. An
// edit after the fact would re-base every report already printed from the
// batch, so the application holds no privilege to make one.
func TestSourceKindCannotBeUpdatedByTheApplication(t *testing.T) {
	f := newTenantFixture(t, "vekst_import_batches_test")

	txA := tenantTx(t, f.app, orgA)
	id := newBatch(t, txA, orgA, f.entityA, f.userA, "org/a/kind", "uploaded")
	if err := txA.Commit(); err != nil {
		t.Fatalf("commit: %v", err)
	}

	tx := tenantTx(t, f.app, orgA)
	defer tx.Rollback() //nolint:errcheck

	_, err := tx.Exec(`UPDATE import_batches SET source_kind = 'ledger' WHERE id = $1`, id)
	if err == nil {
		t.Fatal("the application updated source_kind")
	}
	if got := pgErr(t, err).Code; got != "42501" {
		t.Errorf("refused with SQLSTATE %s, want 42501 (insufficient privilege)", got)
	}

	// A privilege error aborts the transaction, so the second half of this
	// assertion needs its own. The narrowing must not have cost the columns the
	// pipeline does legitimately move.
	tx2 := tenantTx(t, f.app, orgA)
	defer tx2.Rollback() //nolint:errcheck
	if _, err := tx2.Exec(
		`UPDATE import_batches SET status = 'parsing', updated_at = now() WHERE id = $1`, id); err != nil {
		t.Errorf("status is no longer updatable: %v", err)
	}
}

// A batch query outside a tenant transaction raises rather than returning an
// empty result. Zero rows would be rendered by a report as "this customer has
// no imports", which is a wrong answer dressed as a right one.
func TestBatchReadsAreFailClosed(t *testing.T) {
	f := newTenantFixture(t, "vekst_import_batches_test")

	tx, err := f.app.Begin()
	if err != nil {
		t.Fatalf("begin: %v", err)
	}
	defer tx.Rollback() //nolint:errcheck

	var n int
	err = tx.QueryRow(`SELECT count(*) FROM import_batches`).Scan(&n)
	if err == nil {
		t.Fatalf("a read with no tenant context returned %d rows instead of raising", n)
	}
	if got := pgErr(t, err).Code; got != "42704" {
		t.Errorf("raised SQLSTATE %s, want 42704", got)
	}
}
