-- Queries for import_batches (change 2.1, add-file-upload).
--
-- Not one statement here carries an org_id predicate, and that is deliberate --
-- the same rule tenancy.sql states at length. import_batches has a FORCE'd
-- policy restricting it to app_current_org() (migration 00007), and db.InTx
-- sets that context as the transaction's first statement. The policy supplies
-- the filter. A hand-written `WHERE org_id = $1` would return the right rows
-- whether or not the policy existed, so the day someone creates a table and
-- forgets the policy, these queries keep working and nothing fails.
--
-- Writes meant to touch exactly one row are :execrows, never :exec. Row-level
-- security filters UPDATE silently -- a write whose target the policy does not
-- admit affects zero rows and raises nothing -- so the affected-row count is
-- the only signal that "the upload was recorded" was a lie. db.ExactlyOneRow
-- turns a zero count into a named error.
--
-- NO statement in this file writes source_kind on an existing row. A report
-- line is computed from one source kind and the basis label is derived from it,
-- so changing it after rows are persisted would re-base every report already
-- printed from that batch. Migration 00008 revokes the privilege as well; this
-- is the other half of the same rule, and a test asserts the absence.

-- name: InsertImportBatch :one
-- Reserving a batch. The row exists from the moment the upload is requested,
-- not when it completes, so an upload that never arrives is visible as an
-- abandoned batch rather than absent entirely.
--
-- status is passed rather than defaulted: migration 00008 drops the column
-- default precisely so that a row cannot arrive in a state nobody chose.
INSERT INTO import_batches (
    org_id, entity_id, uploaded_by, source_kind, status,
    file_name, declared_bytes, declared_type, file_key, upload_expires_at
) VALUES (
    $1, $2, $3, $4, 'awaiting_upload', $5, $6, $7, $8, $9
)
RETURNING *;

-- name: GetImportBatch :one
-- No org_id predicate: the policy admits only this organisation's rows, so the
-- id alone is enough and a predicate could only narrow it to zero.
SELECT * FROM import_batches WHERE id = $1;

-- name: ListImportBatches :many
-- The imports screen. Newest first, which is the order the index is built in.
SELECT * FROM import_batches
WHERE entity_id = COALESCE(sqlc.narg('entity_id'), entity_id)
ORDER BY created_at DESC
LIMIT $1 OFFSET $2;

-- name: RecordUploadMeasurement :execrows
-- What the measurement job learned by reading the object back. These three
-- columns are the only true facts about the file -- core never sees the bytes,
-- so everything the client said is a signing condition rather than a fact.
--
-- The status move to 'uploaded' happens here and not separately, because
-- migration 00008's import_batches_measured_past_upload constraint makes the
-- two inseparable: a batch cannot be 'uploaded' with a NULL sha256. Splitting
-- them into two statements would make the intermediate state unrepresentable
-- and the first statement fail.
UPDATE import_batches
SET file_sha256  = $2,
    byte_length  = $3,
    content_type = $4,
    status       = 'uploaded',
    updated_at   = now()
WHERE id = $1 AND status = 'awaiting_upload';

-- name: SetImportBatchStatus :execrows
-- Every other state move. The caller has already checked the transition against
-- the table in core/internal/ingest; this is the write, and the `from` argument
-- makes it a compare-and-set so two workers cannot both advance one batch.
UPDATE import_batches
SET status       = $2,
    failure_code = sqlc.narg('failure_code'),
    updated_at   = now()
WHERE id = $1 AND status = $3;

-- name: AbandonExpiredBatch :execrows
-- The expiry job. Guarded on the status rather than on the clock alone, so a
-- job that fires late cannot undo a real upload: by then the batch has moved
-- to 'uploaded' and this matches nothing.
UPDATE import_batches
SET status = 'abandoned', updated_at = now()
WHERE id = $1 AND status = 'awaiting_upload' AND upload_expires_at <= now();

-- name: GetImportBatchByFileHash :one
-- D1, the same file twice. Change 2.6 owns the rejection; this is the lookup it
-- needs, and it is here because the column is this change's. Scoped to imported
-- batches only: a file whose batch was rejected for a broken row must be
-- uploadable again once the customer fixes it.
SELECT * FROM import_batches
WHERE file_sha256 = $1 AND status = 'imported';
